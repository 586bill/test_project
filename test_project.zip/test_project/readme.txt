for the sql part, I create two table.
CustomerNotes and CustomerList 
for customerList 
field id is int auto_increament 
field name is varchar
field phone is varchar

for customernotes
field note_id is int auto_increament 
field cust_id is int 
field note is varchar
field create_date is datetime