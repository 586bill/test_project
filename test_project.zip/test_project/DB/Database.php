<?php
include("db_info.php");

/*this database class can handle the sql execution */

class Database{

    public function __construct(){
        
        $this->conn = new mysqli(__LOCAL__,__USER__, __PASS__, __DATA__);
    }

    public function execute_record($query){
        $this->conn->query($query);
    }

    public function return_record($query){
        return $this->conn->query($query)->fetch_all(MYSQLI_ASSOC);
    }

    public function return_string($string){
        
        return $this->conn->real_escape_string($string);
    }
}

?>