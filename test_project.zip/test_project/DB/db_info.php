<?php
const __LOCAL__ = "localhost";
const __USER__ = "root";
const __PASS__ = "";
const __DATA__ = "test";


?>