<?php

include("DB/Database.php");
include("Customer/Customer.php");
include("Note/Note.php");
date_default_timezone_set('America/Los_Angeles');

$date = date("Y-m-d H:i:s");
extract($_GET, EXTR_OVERWRITE);

if($note_action=='search'){

$cust_note = new Note("", "", $cust_id, 0);

$note_info_array=$cust_note->checkRecord(array('cust_id'=>$cust_note->getCust_id()),'ORDER BY create_date desc');

echo json_encode($note_info_array);

}else {
    if($note_action=='add'){
        $note_info = new Note($date, $note, $cust_id, 0);
        $note_info->addRecord();
    
    }else if($note_action=='update'){
        $note_info = new Note('',$note, $cust_id, $note_id);
        $note_info->updateRecord(array('note'=>'"' .$note_info->getNote(). '"'));

    } else if($note_action=='delete'){
        $note_info = new Note('','', $cust_id, $note_id);
        $note_info->deleteRecord(array('note_id'=> $note_info->getNote_id()));
    }
    $customer = new Customer($cust_id,"","");
    $return_array = array();
    $return_array['customer']=$customer->checkCustmize();
    $return_array['note']= $note_info->checkRecord(array('cust_id'=>'"'.$note_info->getCust_id().'"'),'ORDER BY create_date desc');
    echo json_encode($return_array);

}


?>