/*this function is the middle point when add/udpate/delete note */
function addNote(id_number,saction){
  
    $("#note_action").val(saction);
    $("#InputNote_num").val(id_number);
    if(saction != 'delete'){
      $("#note_table").hide();
    $("#note_information").append('<div id="note_div" class="form-group"><input type="text" name="note" class="form-control" id="note_add" placeholder="Enter note here.." ><br/><button type="button" onclick="submitNote()" class="btn btn-primary">Submit</button></div>');
    }else{
      submitNote();
    }
  }

  /*this function is sending the note information for update and send back json to udpate*/
  function submitNote(){
    
    var extra_info = $('#note_information').serialize();
    var data_link = 'note_list.php?' + extra_info;
    var cust_id = $("#InputNote2").val();
  
    $.ajax({
          type:"get",
          url:data_link,
          data: {},
          success:function(data){

              var de = JSON.parse(data);
              var da = de.note;
              var di = de.customer;

              $("#note_div").remove();
              $("#note_table").show();
              $("#note_tbody").remove();
              $("#note_table").append('<tbody id="note_tbody">');
              for(var i = 0; i<da.length; i++){
                $("#note_tbody").append('<tr><td>'+da[i].create_date+'</td><td>'+da[i].note+'</td><td><button type="button" class="btn btn-warning" onclick="addNote('+da[i].note_id+', &quot;update&quot;)">Update</button></td><td><button type="button" class="btn btn-danger"  onclick="addNote('+da[i].note_id+', &quot;delete&quot;)">Delete</button></td></tr>');
              }
              $("#note_table").append('</tbody>');
  
              getCall(di);
   
              clearForm('note_information');
              $("#InputNote2").val(cust_id);
     
          },
          fail:function(){
              alert('fail');
          }
          
      }); 
  }
  /*this function is sending the note information in the intial and send back json to udpate*/
  function fillNote(cust_id){
    if($("#note_table").is(":hidden")){
      $("#note_table").show();
    }
    $("#InputNote2").val(cust_id);
    var extra_info = 'note_action=search&cust_id='+cust_id;
    var data_link = 'note_list.php?' + extra_info;
    $.ajax({
          type:"get",
          url:data_link,
          data: {},
          success:function(data){
              
            var da = JSON.parse(data);       
       
            $("#note_tbody").remove()
            $("#note_table").append('<tbody id="note_tbody">');
            for(var i = 0; i<da.length; i++){
                $("#note_tbody").append('<tr><td>'+da[i].create_date+'</td><td>'+da[i].note+'</td><td><button type="button" class="btn btn-warning" onclick="addNote('+da[i].note_id+', &quot;update&quot;)">Update</button></td><td><button type="button" class="btn btn-danger" onclick="addNote('+da[i].note_id+', &quot;delete&quot;)">Delete</button></td></tr>');
              }
            $("#note_table").append('</tbody>');         
          },
          fail:function(){
              alert('fail');
          }
          
      }); 
  }
  
  /*this function is sending the customer information in the intial and send back json to udpate*/
  function saveCustomer(){
      if($('#InputName').val() == "" || $('#InputPhone').val() == ""){
        alert("Name or phone number is empty.");
      }
      else{
  
        var extra_info = $('#cust_information').serialize();
        var data_link = 'cust_backend.php?' + extra_info;
        
        $.ajax({
          type:"get",
          url:data_link,
          data: {},
          success:function(data){
              
            var da = JSON.parse(data);            
            getCall(da);  
            clearForm('cust_information');
           
          },
          fail:function(){
              alert('fail');
          }
          
      }); 
          
    }
  
  }
  /*this is the return function call back, it will remove the old table info and generate a new table */
  function getCall(da){
     $("#cust_tbody").remove()
              $("#cust_table").append('<tbody id="cust_tbody">');
              for(var i = 0; i<da.length; i++){
                $("#cust_table").append('<tr><td>'+da[i].name+'</td><td>'+da[i].phone+'</td><td>'+da[i].note+' (<a data-toggle="modal" data-target="#noteModal" onclick="fillNote('+da[i].id+')">click to view previous note</a>)</td><td><button type="button" class="btn btn-warning" data-toggle="modal" data-target="#custModal" onclick="fillCustomer(&quot;'+da[i].name+'&quot;, &quot;'+da[i].phone+'&quot;, '+da[i].id+', '+da[i].note_id+', &quot;'+da[i].note+'&quot;)">Update</button></td><td><button type="button" class="btn btn-danger" data-toggle="modal" data-target="#confirmationDelete" onclick="fillDelete('+da[i].id+', '+da[i].note_id+')">Delete</button></td></tr>');
              }
              $("#cust_table").append('</tbody>');
  
  }
  
  function deleteRecord(){
    var extra_info = $('#cust_information2').serialize();
        var data_link = 'cust_backend.php?' + extra_info;
        console.log(data_link);
        
            $.ajax({
          type:"get",
          url:data_link,
          data: {},
          success:function(data){
              alert(data);
              var da = JSON.parse(data);
              getCall(da);
              console.log(data);
           
          },
          fail:function(){
              alert('fail');
          }
          
      }); 
  }
  
  /*this function will fill basic customer to input box */
  function fillCustomer(cust_name, cust_phone,cust_id,note_id, cust_note){
  
      $('#InputName').val(cust_name);
      $('#InputPhone').val(cust_phone);
      $('#InputNote').val(cust_note);
      $('#InputHidden').val(cust_id);
      $('#InputHidden2').val(note_id);
      $("#InputAction").val("update");
  }
  /*this function will fill basic info to hidden input box */
  function fillDelete(cust_id,note_id){
  
    $('#InputDelete').val(cust_id);
      $('#InputDelete2').val(note_id);
      $("#InputAction2").val("delete");
      
  }
   
  function addAction(){
    $("#InputAction").val("add");
  }

  /*this function will clean the form after CRUD finish */
  
  function clearForm(idname){
  
    $('#'+idname).find("input[type=text], textarea").val("");
    $('#note_div').remove();
  }
  