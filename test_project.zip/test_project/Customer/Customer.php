<?php
/*this customer class can handle customer's contact info like name and phone number */
class Customer{
    private $cust_id;
    private $name;
    private $phone;
 /*construct for Customer class it will check real escape from database class */
    public function __construct($cust_id, $name, $phone){
        $database = new Database();
        $this->cust_id = $database->return_string($cust_id);
        $this->name = $database->return_string($name);
        $this->phone = $database->return_string($phone);
    }

    public function getName(){
        return  $this->name;
    }

    public function getCust_id(){
        return $this->cust_id;
    }

    public function getPhone(){
        return $this->phone;
    }

    public function addRecord(){
        $cust_array = array('name'=>'"' . $this->name. '"', 'phone'=>'"' . $this->phone. '"');
        $query = array_to_string('create','customerlist', '' , array(),'', $cust_array);
        $database = new Database();
        $database->execute_record($query); 

    }
 /*search method for customer class 1st parameter is boolean to check if join
 2nd parameter is the second table if you join the other table
 3rd 4th parameter are the common field that two table can join
 5th parameter is like left join, right join, inner join
 6th parameter is group by something if need
 7th-10th is the order by information */
    public function checkRecord( $join, $table2, $join_name, $origin_name, $join_type, $group_id, $order_id, $order_type, $order_id2, $order_type2){
        $extra_info = $join == true ? $join_type.' '.$table2.' on '.$origin_name.' = '.$join_name : "";

        $cust_string = $this->cust_id != "" ? ' WHERE id = '.$this->cust_id : ' WHERE name = '. '"' . $this->name. '" and phone = ' . '"' . $this->phone. '"';
        $cust_string = $group_id != "" ? $extra_info . ' GROUP BY '.$group_id : $cust_string;
        $cust_string = $order_id != "" ? $extra_info . ' ORDER BY '.$order_id.' '.$order_type : $cust_string;
        $cust_string =  $order_id2 != "" ? $extra_info . ' ORDER BY '.$order_id2.' '.$order_type2 : $cust_string;


        $query = array_to_string('search','customerlist', $cust_string, array(), $extra_info, array());
        $database = new Database();
        return($database->return_record($query));
    }

/*customize search method */
    public function checkCustmize(){
        $query = 'SELECT * FROM customerlist LEFT JOIN (SELECT * FROM customerNotes WHERE (note_id) in ( SELECT max(note_id) FROM customerNotes GROUP BY cust_id) ORDER BY note_id) t2 on customerlist.id = t2.cust_id   GROUP BY customerlist.id';
        $database = new Database();
        return($database->return_record($query));
    }
    
 /*update method for customer class 1st parameter is an array like array('note'=> '"'.$cust_note.'"' */
    public function updateRecord($cust_array2){
        $cust_String = ' WHERE id = '.$this->cust_id;
        $query = array_to_string('update','customerlist', $cust_String, $cust_array2,'',array());
        $database = new Database();
        $database->execute_record($query);
    }
/*delete method for customer class */
    public function deleteRecord(){
        $cust_String = ' WHERE id = '.$this->cust_id;
        $query = array_to_string('delete','customerlist', $cust_String, array(),'',array());
        $database = new Database();
        $database->execute_record($query); 
    }

}
/*this function used to generate sql string and send back */

function array_to_string($action,$table, $condition, $array2,$extra_info,$array){
    if($action == 'create'){
        $cust_key = implode(', ' ,array_keys($array));
        $cust_value = implode(', ' , array_values($array));

        $query = 'INSERT INTO '.$table.' ('.$cust_key.') VALUES ('.$cust_value.')';
    }else if($action == 'search'){  
            if($condition == ""){
                $query = 'SELECT * FROM '.$table.' '.$extra_info;
            }else{     
                $query = 'SELECT * FROM '.$table.' '.$extra_info.' '.$condition; 
            }
    }else if($action == 'update'){ 
            $condition2 = '';
            for($i = 0; $i < sizeof($array2); $i++){
            
                if($i + 1 ==  sizeof($array2)){
                    
                    $condition2 = $condition2 . array_keys($array2)[$i] . '=' . array_values($array2)[$i];
                }else{
                    $condition2 = $condition2 . array_keys($array2)[$i] . '=' . array_values($array2)[$i]. ', ';
                }
            }      
            $query = 'UPDATE '.$table.' SET '.$condition2.' '.$condition; 
    }else if($action == 'delete'){       
            $query = 'DELETE from '.$table.' '.$condition; 
        }
    return $query;
}

?>