<?php
include("DB/Database.php");
include("Customer/Customer.php");
include("Note/Note.php");
date_default_timezone_set('America/Los_Angeles');

$customer = new Customer("","","");
$cust_info = $customer->checkCustmize();


?>
<!DOCTYPE html>
<html>
    <head>
        <title>test project</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <script src="js/jquery-3.4.1.js"></script>  
        <script src="js/bootstrap.min.js"></script>
        <script src="js/test_project.js"></script>
        <style>
          .modal-content {
            width: 800px;
          }
        </style>
    </head>
    <body>
      <div class="test_body">

        <!-- modal for customer input -->
        <div class="modal fade" id="custModal" tabindex="-1" role="dialog" aria-labelledby="titleLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="titleLabel">Customer Info:</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true" onclick="clearForm('cust_information')" >&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <form id="cust_information">
                  <div class="form-group">
                    <input type="hidden" name="cust_action" class="form-control" id="InputAction" >
                  </div>     
                  <div class="form-group">
                    <input type="hidden" name="cust_id" class="form-control" id="InputHidden" >
                  </div> 
                  <div class="form-group">
                    <input type="hidden" name="note_id" class="form-control" id="InputHidden2" >
                  </div> 
                  <div class="form-group">
                    <label for="InputName">Name:</label>
                    <input type="text" name="cust_name" class="form-control" id="InputName"  placeholder="Enter Name">
                  </div>
                  <div class="form-group">
                    <label for="InputPhone">Phone:</label>
                    <input type="text" name="cust_phone" class="form-control" id="InputPhone" placeholder="Enter Phone">
                  </div>
                  <div class="form-group">
                    <label for="InputNote">Note:</label>
                    <input type="text" name="cust_note" class="form-control" id="InputNote" placeholder="Enter Note">
                  </div> 
                </form>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="clearForm('cust_information')">Close</button>
                <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="saveCustomer()">Save changes</button>
              </div>
            </div>
          </div>
        </div>

        <!-- modal for confirmation -->
        <div class="modal fade" id="confirmationDelete" tabindex="-1" role="dialog" aria-labelledby="confirmationTitle" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="confirmationTitle">Confirmation</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true" onclick="clearForm('cust_information')">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <form id="cust_information2">
                  <div class="form-group">
                    <input type="hidden" name="cust_action" class="form-control" id="InputAction2" >
                  </div>     
                  <div class="form-group">
                    <input type="hidden" name="cust_id" class="form-control" id="InputDelete" >
                  </div> 
                  <div class="form-group">
                    <input type="hidden" name="note_id" class="form-control" id="InputDelete2" >
                  </div> 
                </form>
                  Do you want to delete this record?
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="clearForm('cust_information')">Close</button>
                <button type="button" class="btn btn-primary" data-dismiss="modal"  onclick="deleteRecord()">Confirm</button>
              </div>
            </div>
          </div>
        </div>

        <!-- modal for note list -->
        <div class="modal fade" id="noteModal" tabindex="-1" role="dialog" aria-labelledby="noteTitle" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="noteTitle">Note</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true" onclick="clearForm('note_information')"  >&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <form id="note_information">
                  <div class="form-group">
                    <input type="hidden" name="cust_id" class="form-control" id="InputNote2" >
                  </div> 
                  <div class="form-group">
                    <input type="hidden" name="note_id" class="form-control" id="InputNote_num" >
                  </div>
                  <div class="form-group">
                    <input type="hidden" name="note_action" class="form-control" id="note_action" >
                  </div> 
                  <table class="table" id="note_table">
                    <thead>
                      <tr>
                        <th>Date</th>
                        <th>Note</th>
                        <th><button type="button" class="btn btn-success" onclick="addNote('','add')">Add</button></th>
                      </tr>
                    </thead>
                  </table>
                </form>
              </div>
            </div>
          </div>
        </div>

        <!--Customer table-->      

        <table class="table" id="cust_table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Phone #</th>
              <th>Lastest Note</th>
              <th><button type="button" class="btn btn-success" data-toggle="modal" data-target="#custModal" onclick="addAction()">Add</button></th>
            </tr>
          </thead>
          <tbody id="cust_tbody">
          <?php
            for($i=0; $i<sizeof($cust_info); $i++){
              echo '<tr>
                      <td>'.$cust_info[$i]['name'].'</td>
                      <td>'.$cust_info[$i]['phone'].'</td>
                      <td>'.$cust_info[$i]['note'].' (<a data-toggle="modal" data-target="#noteModal" onclick="fillNote('.$cust_info[$i]['id'].')">click to view previous note</a>)</td>
                      <td><button type="button" class="btn btn-warning" data-toggle="modal" data-target="#custModal" onclick="fillCustomer(&quot;'.$cust_info[$i]['name'].'&quot;, &quot;'.$cust_info[$i]['phone'].'&quot;, '.$cust_info[$i]['id'].', '.$cust_info[$i]['note_id'].', &quot;'.$cust_info[$i]['note'].'&quot;)">Update</button></td>
                      <td><button type="button" class="btn btn-danger" data-toggle="modal" data-target="#confirmationDelete" onclick="fillDelete('.$cust_info[$i]['id'].','.$cust_info[$i]['note_id'].')">Delete</button></td>
                    </tr>';
                      }
                  
                  ?>

          </tbody>    
        </table>
      </div>
    </body>
</html>
