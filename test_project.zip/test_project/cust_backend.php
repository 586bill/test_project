<?php
date_default_timezone_set('America/Los_Angeles');
include("DB/Database.php");
include("Customer/Customer.php");
include("Note/Note.php");

extract($_GET, EXTR_OVERWRITE);

$date = date("Y-m-d H:i:s");

if($cust_action=='add'){
    $customer = new Customer("",$cust_name, $cust_phone);
    $cust_info = $customer->checkRecord(false, '', '', '', '', '', '','','','');
    if(sizeof($cust_info)==0){
        $customer->addRecord();
        if($cust_note!=""){
            $cust_info = $customer->checkRecord(false, '', '', '', '', '', 'id','desc','','');
            $note = new Note($date,$cust_note , $cust_info[0]['id'], $note_id);
            $note->addRecord();
            $note_info = $note->checkRecord(array('note'=> '"'.$cust_note.'"'), 'ORDER BY note_id');
        }
    }


}else if($cust_action=='update'){
    $customer = new Customer($cust_id,$cust_name, $cust_phone);
    $customer->updateRecord(array('name'=>'"' . $cust_name. '"', 'phone'=>'"' . $cust_phone. '"'));
    $note = new Note($date, $cust_note, $cust_id, $note_id);
    $note->updateRecord(array('note'=>'"' . $cust_note. '"', 'create_date'=>'"' . $date. '"'));
}else if($cust_action=='delete'){
    $customer = new Customer($cust_id,"","");
    $customer->deleteRecord();
    $note = new Note("", "", $cust_id, $note_id);
    $note->deleteRecord(array('cust_id'=> $cust_id));
}

$cust_info_array = $customer->checkCustmize();
echo json_encode($cust_info_array);

?>