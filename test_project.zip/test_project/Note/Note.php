<?php
/*this note class can handle customer's note */
class Note{
    private $create_date;
    private $note;
    private $cust_id;
    private $note_id;

    /*construct for note class it will check real escape from database class */
    public function __construct($create_date, $note, $cust_id, $note_id){
        $database = new Database();
        $this->create_date = $database->return_string($create_date);
        $this->note = $database->return_string($note);
        $this->cust_id = $database->return_string($cust_id);
        $this->note_id = $database->return_string($note_id);
    }

    public function getNote(){
        return  $this->note;
    }

    public function getCust_id(){
        return $this->cust_id;
    }

    public function getNote_id(){
        return $this->note_id;
    }

    public function getCreate_date(){
        return $this->create_date;
    }
    /*add method for note class */
    public function addRecord(){
        $cust_array = array('cust_id'=>'"' . $this->cust_id. '"', 'note'=>'"' . $this->note. '"', 'create_date'=>'"' . $this->create_date. '"');
        $query = array_to_string2('create','customernotes', $cust_array, array(),'');
        $database = new Database();
        $database->execute_record($query); 

    }
    
    /*search method for note class 1st parameter is an array like array('note'=> '"'.$cust_note.'"' */
    /*second is extra string like 'ORDER BY create_date desc' */
    public function checkRecord($cust_array, $extra_info){
        $query = array_to_string2('search','CustomerNotes', $cust_array, array(),$extra_info);
        $database = new Database();
        return($database->return_record($query));
    }

    /*update method for note class 1st parameter is an array like array('note'=> '"'.$cust_note.'"' */
    public function updateRecord($cust_array2){
        $cust_array = array('note_id'=>$this->note_id);
        $query = array_to_string2('update','CustomerNotes', $cust_array, $cust_array2,'');
        $database = new Database();
        $database->execute_record($query);
    }

    /*delete method for note class 1st parameter is an array like array('note'=> '"'.$cust_note.'"' */
    public function deleteRecord($cust_array){
        $query = array_to_string2('delete','CustomerNotes', $cust_array, array(),'');
        $database = new Database();
        $database->execute_record($query); 
    }
    
}
/*this function used to generate sql string and send back */
function array_to_string2($action,$table, $array, $array2,$extra_info){
    

    if($action == 'create'){
        $cust_key = implode(', ' ,array_keys($array));
        $cust_value = implode(', ' , array_values($array));

        $query = 'INSERT INTO '.$table.' ('.$cust_key.') VALUES ('.$cust_value.')';
    }else{
        $condition = '';
        for($i = 0; $i < sizeof($array); $i++){
            
            if($i + 1 ==  sizeof($array)){
                
                $condition = $condition . array_keys($array)[$i] . '=' . array_values($array)[$i];
            }else{
                $condition = $condition . array_keys($array)[$i] . '=' . array_values($array)[$i]. 'and ';
            }
        }


        if($action == 'search'){  
            if($condition == ""){
                $query = 'SELECT * FROM '.$table.' '.$extra_info;
            }else{     
                $query = 'SELECT * FROM '.$table.' WHERE '.$condition.' '.$extra_info; 
            }
        }else if($action == 'update'){ 
            $condition2 = '';
            for($i = 0; $i < sizeof($array2); $i++){
            
                if($i + 1 ==  sizeof($array2)){
                    
                    $condition2 = $condition2 . array_keys($array2)[$i] . '=' . array_values($array2)[$i];
                }else{
                    $condition2 = $condition2 . array_keys($array2)[$i] . '=' . array_values($array2)[$i]. ', ';
                }
            }      
            $query = 'UPDATE '.$table.' SET '.$condition2.' WHERE '.$condition; 
        }else if($action == 'delete'){       
            $query = 'DELETE from '.$table.' WHERE '.$condition; 
        }

    } 

    return $query;
}

?>